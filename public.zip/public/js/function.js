// RMIT University Vietnam
//   Course: COSC2430 Web Programming
//   Semester: 2023A
//   Assessment: Assignment 2
//   Author: Nguyen Hoang Phuong, Nguyen Thach Khanh Dzi, Hanjun Lee, Taesung Yoon, Pham Le Gia Huy
//   ID: S3924593, S3980883, S3732878, S3847581, S3975371
//   Acknowledgement: Acknowledge the resources that you use here. 


const extraImages = document.querySelectorAll('.extraImage');
const mainImage = document.querySelector('.mainImage');

const buttons = document.querySelectorAll('.btn[data-bs-toggle="button"]');

extraImages.forEach(extraImage => {
  extraImage.addEventListener('click', function() {
    mainImage.src = this.src;
  });
});

buttons.forEach(button => {
  button.addEventListener('click', () => {
    buttons.forEach(otherButton => {
      if (otherButton !== button) {
        otherButton.setAttribute('aria-pressed', 'false');
        otherButton.classList.remove('active');
      }
    });
  });
});

// Function to toggle password visibility
function togglePasswordVisibility(inputId1, inputId2) {
  const passwordInput1 = document.getElementById(inputId1);
  const passwordInput2 = document.getElementById(inputId2);
  const button = document.querySelector(`button[onclick="togglePasswordVisibility('${inputId1}', '${inputId2}')"]`);

  if (passwordInput1.type === "password" && passwordInput2.type === "password") {
    passwordInput1.type = "text";
    passwordInput2.type = "text";
    button.textContent = "Hide";
  } else {
    passwordInput1.type = "password";
    passwordInput2.type = "password";
    button.textContent = "Show";
  }
}

// Function to check if passwords match (you can keep your existing function)
function checkPasswordMatch(passwordId, confirmPasswordId, messageId) {
  const passwordInput = document.getElementById(passwordId);
  const confirmPasswordInput = document.getElementById(confirmPasswordId);
  const passwordMatchMessage = document.getElementById(messageId);

  if (passwordInput.value === confirmPasswordInput.value) {
    passwordMatchMessage.textContent = 'Passwords match.';
    passwordMatchMessage.classList.remove('text-danger');
    passwordMatchMessage.classList.add('text-success');
  } else {
    passwordMatchMessage.textContent = 'Passwords do not match.';
    passwordMatchMessage.classList.remove('text-success');
    passwordMatchMessage.classList.add('text-danger');
  }
}

// choose what is the role want to regis
const actionSelect = document.getElementById('action');
      const regisLinks = {
        Customer: document.getElementById('regiscus'),
        Vendor: document.getElementById('regisven'),
        Shipper: document.getElementById('regisship')
      };

      // Function to toggle the visibility of registration links based on the selected option
      function toggleRegistrationLinks() {
        const selectedOption = actionSelect.value;
        for (const key in regisLinks) {
          if (regisLinks.hasOwnProperty(key)) {
            const link = regisLinks[key];
            link.style.display = key === selectedOption ? 'block' : 'none';
          }
        }
      }

      // Add an event listener to the select element to toggle the links when the option changes
      actionSelect.addEventListener('change', toggleRegistrationLinks);

      // Initial toggle based on the default selected option
      toggleRegistrationLinks();


