// RMIT University Vietnam
//   Course: COSC2430 Web Programming
//   Semester: 2023A
//   Assessment: Assignment 2
//   Author: Nguyen Hoang Phuong, Nguyen Thach Khanh Dzi, Hanjun Lee, Taesung Yoon, Pham Le Gia Huy
//   ID: S3924593, S3980883, S3732878, S3847581, S3975371
//   Acknowledgement: Acknowledge the resources that you use here. 


const extraImages = document.querySelectorAll('.extraImage');
const mainImage = document.querySelector('.mainImage');

const buttons = document.querySelectorAll('.btn[data-bs-toggle="button"]');

extraImages.forEach(extraImage => {
    extraImage.addEventListener('click', function () {
        mainImage.src = this.src;
    });
});

buttons.forEach(button => {
    button.addEventListener('click', () => {
        buttons.forEach(otherButton => {
            if (otherButton !== button) {
                otherButton.setAttribute('aria-pressed', 'false');
                otherButton.classList.remove('active');
            }
        });
    });
});




document.getElementById("submitSearch").addEventListener("click", function () {
    let searchInput = document.querySelector("#search input");

    const searchText = searchInput.value;
    const searchURL = `http://www.localhost:3000/search/${encodeURIComponent(searchText)}`;

    if (searchInput.value != "") {
        document.getElementById("search").action = searchURL;
        document.getElementById("search").submit();
    }
});