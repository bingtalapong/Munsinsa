const { mongoose } = require("mongoose");

const CouponSchema = new mongoose.Schema({
  id: { type: String, required: true },
  detail: {
    type: String,
    required: true,
  },
});
const Coupon = mongoose.model("Coupon", CouponSchema);
module.exports = Coupon;
