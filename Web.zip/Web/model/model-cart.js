const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let CartSchema = new Schema({
  // User: {
  //   type: mongoose.Schema.Types.ObjectId,
  //   ref: "User",
  // },
  goods: {
    item: {
      id: {
        type: String,
        requried: true,
        unique: true,
      },
      brand: {
        type: String,
      },
      name: {
        type: String,
        required: true,
      },
      price: {
        type: String,
        required: true,
      },
      category: {
        type: String,
        enum: ["Hat", "Tops", "Shoes", "Pants"],
      },
      images: [String],
    },
    quantity: {
      type: Number,
      required: true,
    },
  },
});

const Cart = mongoose.model("Cart", CartSchema);
module.exports = Cart;


