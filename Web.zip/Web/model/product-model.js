// const { mongoose } = require("../config/mongoose");
const mongoose = require("mongoose");

// Define the product schema
const ProductSchema = new mongoose.Schema({

  id: {
    type: String,
    requried: true,
    unique: true
  },
  brand: {
    type: String,
  },
  name: {
    type: String,
    required: true
  },
  price: {
    type: String,
    required: true
  },
  category: {
    type: String,
    enum: ['Hat', 'Tops', 'Shoes', 'Pants']
  },
  image: {String},
  subImages: [String]
});




// Create the product model
const Product = mongoose.model("Product", ProductSchema);
module.exports = Product;

