
const extraImages = document.querySelectorAll('.extraImage');
const mainImage = document.querySelector('.mainImage');

const buttons = document.querySelectorAll('.btn[data-bs-toggle="button"]');

extraImages.forEach(extraImage => {
  extraImage.addEventListener('click', function() {
    mainImage.src = this.src;
  });
});

buttons.forEach(button => {
  button.addEventListener('click', () => {
    buttons.forEach(otherButton => {
      if (otherButton !== button) {
        otherButton.setAttribute('aria-pressed', 'false');
        otherButton.classList.remove('active');
      }
    });
  });
});

const contentContainer = document.querySelector('.content');
const descriptionButton = document.querySelector('.btn.active');
const detailImageButton = document.querySelector('.btn:not(.active):nth-child(2)');
const sizeAndFitButton = document.querySelector('.btn:not(.active):nth-child(3)');
const shippingAndReturnsButton = document.querySelector('.btn:not(.active):nth-child(4)');

function showDescription() {
    contentContainer.innerHTML = '<p>Description content goes here...</p>';
}

function showDetailImage() {
    contentContainer.innerHTML = '<img src="images/extraImage1.png" alt="Detail Image">';
}

function showSizeNFit() {
    contentContainer.innerHTML = '<p>Size and Fit information goes here...</p>';
}

function showShippingNReturns() {
    contentContainer.innerHTML = '<p>Shipping and Returns information goes here...</p>';
}
