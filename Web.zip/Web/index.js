const express = require("express");
const app = express();
const mongoose = require("mongoose");
const products = require("./db/products");



// MongoDB Atlas connection
const mongoUrl =
  "mongodb+srv://phuong1000501:1234@cluster0.fa5boxf.mongodb.net/";

// Connect to MongoDB Atlas
mongoose
  .connect(mongoUrl, { useNewUrlParser: true })
  .then(() => console.log("Connected to MongoDB Atlas"))
  .catch((err) => console.error("Error connecting to MongoDB Atlas", err));



app.set("view engine", "ejs");
app.use(express.static(__dirname + "/public"));
const Cart = require("./model/model-cart");
// const Coupon = require("./model/model-coupon");
// const Like = require("./model/model-like");
//const cors = require("cors")

app.use(express.urlencoded({ extended: true }));


//VENDOR
app.get("/vendor/add", (req, res) => {
  res.render("add-new-product");
})

// app.post('/vendor/add', (req, res) => {
//   console.log(req.body);

  
//   .then(console.log('work????'))
//   .catch((error) => {console.error});
// });

 app.get("/vendor/products", (req, res) => {
   const products = Product.find({});

   res.render("vendor-products", { products });

 })

//CUSTOMER
 app.get("/customer/main", (req, res) => {
   res.render("customer-main", { products });
 })

app.get("/customer/main",  (req, res) => {
  // const allProducts = await Product.find({});
  // const hats = await Product.find({ category: "Hat" });
  // const tops = await Product.find({ category: "Tops" });    //WAIT UNTIL APPLYINNG MONGODB 
  // const pants = await Product.find({ category: "Pants" });   for "add-product". Now just use static 
  // const shoes = await Product.find({ category: "Shoes" });   data from "products.js" in "db"
  // res.render("customer-main", {
  //   products: allProducts,
  //   hats: hats, 
  //   tops: tops,
  //   pants: pants,
  //   shoes: shoes,
  // });

// res.render('customer-main', {products});

});

app.post("/customer/viewProduct", async (req, res) => {   //from 'customer-main.ejs'
  const pid = await req.body.id;
  for (let i = 0; i < products.length; i++) {
    if(products[i].id === pid){
      product = products[i];
    }
  }
  console.log('buta');

  res.render()
});




 app.get("/customer/productDetail",  (req,res) =>{
  const pid = req.body.id;
  // const product = Product.findOne({ id: pid });    WAIT UNTIL APPLYING mongodb AND "add product"
  let product;
  for (let i = 0; i < products.length; i++) {
    if(products[i].id === pid){
      product = products[i];
    }
  }
  console.log(product.name);
  //  res.render("product-detail", { product });
 })

 





app.listen(3000, () => {
  console.log("Server is up on port 3000");
});





